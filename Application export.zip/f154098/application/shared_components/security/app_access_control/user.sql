prompt --application/shared_components/security/app_access_control/user
begin
--   Manifest
--     ACL ROLE: User
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>79077224710815258366
,p_default_application_id=>154098
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BFWQWQOAOYNDLPZ'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(98869282381535293388)
,p_static_id=>'USER'
,p_name=>'User'
,p_description=>wwv_flow_string.join(wwv_flow_t_varchar2(
'A regular user. Can only visualize data from the SQL database.',
'No administrative access.'))
,p_version_scn=>15523952863187
);
wwv_flow_imp.component_end;
end;
/
