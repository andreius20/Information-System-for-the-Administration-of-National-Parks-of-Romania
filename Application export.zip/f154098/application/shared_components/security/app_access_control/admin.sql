prompt --application/shared_components/security/app_access_control/admin
begin
--   Manifest
--     ACL ROLE: Admin
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>79077224710815258366
,p_default_application_id=>154098
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BFWQWQOAOYNDLPZ'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(98867585054808767019)
,p_static_id=>'ADMIN'
,p_name=>'Admin'
,p_description=>'Role with administrative rights. Can perform ADD,DELETE and UPDATE operations on the SQL database.'
,p_version_scn=>15523952392977
);
wwv_flow_imp.component_end;
end;
/
