prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>79077224710815258366
,p_default_application_id=>154098
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BFWQWQOAOYNDLPZ'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Show_organization'
,p_alias=>'SHOW-ORGANIZATION'
,p_step_title=>'Show_organization'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31551034854748580683)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(96803893912211970028)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(96803377824486969977)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(96803957077280970056)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31551035533879580684)
,p_plug_name=>'Show_organization'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(96803821821076969998)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "ID",',
'       "ID_PARC",',
'       ( select l1."NAME" from "PARCURI_NATIONALE" l1 where l1."ID" = m."ID_PARC") "ID_PARC_L$1",',
'       "NUME",',
'       "POZITIE",',
'       "SALARIU",',
'       "ATRIBUTII",',
'       "SEMNARE_CONTRACT",',
'       "TERMINARE_CONTRACT"',
'from "PERSONAL_PARC" m'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P11_ORDER_BY", "orderBys": [{"key":"NUME","expr":"\"NUME\" asc"},{"key":"POZITIE","expr":"\"POZITIE\" asc"},{"key":"ID_PARC_L$1","expr":"\"ID_PARC_L$1\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(31551036174437580687)
,p_region_id=>wwv_flow_imp.id(31551035533879580684)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'NUME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'POZITIE'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'POZITIE'
,p_badge_column_name=>'ID_PARC_L$1'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31551036610364580687)
,p_name=>'P11_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(31551035533879580684)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_item_default=>'NUME'
,p_prompt=>'Order By'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Nume;NUME,Pozitie;POZITIE,Id Parc L$1;ID_PARC_L$1'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(96803952981683970054)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_attribute_01=>'NONE'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
