prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>79077224710815258366
,p_default_application_id=>154098
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BFWQWQOAOYNDLPZ'
);
wwv_flow_imp_page.create_page(
 p_id=>13
,p_name=>'Show_on_map'
,p_alias=>'SHOW_ON_MAP'
,p_step_title=>'Show_on_map'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(96795352347026380819)
,p_plug_name=>'Map of Romania'
,p_region_name=>'mymap'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(96803881428531970023)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'   #map {',
'      height: 100%;',
'   }',
'   #mymap .t-Region-body {',
'      height: 500px !important;',
'   }',
'</style>',
'<div id="map"></div>',
'<script>',
'   var map;',
'   function initMap() {',
'      map = new google.maps.Map(document.getElementById(''map''), {center: {lat: 45.94,lng: 25.01}, zoom: 6});',
'   }',
'</script>',
'',
'<script async defer ',
'      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC2DatUg-jfPqzbBTHB2T3bT9CRa3ZDGm0&callback=initMap"> ',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(96795352565061380821)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(96795352347026380819)
,p_button_name=>'FIND_PARK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(96803955464042970055)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Find Park'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(96795353184010380827)
,p_name=>'P13_PARKS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(96795352347026380819)
,p_use_cache_before_default=>'NO'
,p_prompt=>'List of national parks'
,p_display_as=>'NATIVE_COMBOBOX'
,p_lov=>' Select Name || '' National Park,'' || Location || '','' || ''Romania'' from parcuri_nationale'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(96803952981683970054)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'15'
,p_attribute_07=>'N'
,p_attribute_09=>'0'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(96795352622020380822)
,p_name=>'Get location'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(96795352565061380821)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(96795352788374380823)
,p_event_id=>wwv_flow_imp.id(96795352622020380822)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var map = new google.maps.Map(document.getElementById(''map''), {zoom: 15});',
'var geocoder = new google.maps.Geocoder();',
'var address = document.getElementById(''P13_PARKS'').value;',
'geocoder.geocode({''address'': address}, function(results, status) {',
'   if (status === ''OK'') {',
'       map.setCenter(results[0].geometry.location);',
'       var marker = new google.maps.Marker({map: map, position: results[0].geometry.location});',
'       zoom: 15;',
'   } else {',
'       alert(''Geocode was not successful for the following reason: '' + status);',
'   }',
'});',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(96795354527064380841)
,p_name=>'Find_address'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P13_PARKS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(96795354672412380842)
,p_event_id=>wwv_flow_imp.id(96795354527064380841)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var map = new google.maps.Map(document.getElementById(''map''), {zoom: 15});',
'var geocoder = new google.maps.Geocoder();',
'var address = document.getElementById(''P13_PARKS'').value;',
'geocoder.geocode({''address'': address}, function(results, status) {',
'   if (status == ''OK'') {',
'       map.setCenter(results[0].geometry.location);',
'       var marker = new google.maps.Marker({map: map, position: results[0].geometry.location});',
'       zoom: 15;',
'   } else {',
'       alert(''Geocode was not successful for the following reason: '' + status);',
'   };',
'  document.getElementById(''map'').focus();',
'});',
''))
);
wwv_flow_imp.component_end;
end;
/
